package gg.polonium.common;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Wspólny rdzeń (Java 8): polluje lokalny host launchera
 * (127.0.0.1:8905/api/modules).
 * Format wpisu: {"id":"killaura","enabled":true,"settings":{"range":3.2,"cps":12}}
 */
public final class HostState {
    private static final String URL = "http://127.0.0.1:8905/api/modules";
    private static final Map<String, JsonObject> MODS = new ConcurrentHashMap<String, JsonObject>();
    private static volatile boolean running = false;

    private HostState() {}

    public static void start() {
        if (running) return;
        running = true;
        Thread t = new Thread(new Runnable() {
            @Override public void run() { loop(); }
        }, "polonium-host");
        t.setDaemon(true);
        t.start();
    }

    private static String get() throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(URL).openConnection();
        c.setConnectTimeout(2000);
        c.setReadTimeout(2000);
        c.setRequestMethod("GET");
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        return sb.toString();
    }

    private static void loop() {
        while (running) {
            try {
                // new JsonParser().parse(): deprecated w nowych gson, ale jedyne co działa i na 2.2 (1.8.9) i na 2.11
                JsonElement el = new JsonParser().parse(get());
                if (el.isJsonArray()) {
                    JsonArray arr = el.getAsJsonArray();
                    MODS.clear();
                    for (JsonElement e : arr) {
                        if (!e.isJsonObject()) continue;
                        JsonObject o = e.getAsJsonObject();
                        if (o.has("id")) MODS.put(o.get("id").getAsString(), o);
                    }
                }
            } catch (Exception ignored) {
                // host zgaszony = cheaty cicho nie działają, gra chodzi normalnie
            }
            try {
                Thread.sleep(750);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    public static boolean isOn(String id) {
        JsonObject o = MODS.get(id);
        return o != null && o.has("enabled") && o.get("enabled").getAsBoolean();
    }

    public static double getDouble(String id, String key, double def) {
        try {
            JsonObject o = MODS.get(id);
            if (o != null && o.has("settings")) {
                JsonObject s = o.get("settings").getAsJsonObject();
                if (s.has(key)) return s.get(key).getAsDouble();
            }
        } catch (Exception ignored) {}
        return def;
    }

    public static int getInt(String id, String key, int def) {
        return (int) Math.round(getDouble(id, key, def));
    }
}
