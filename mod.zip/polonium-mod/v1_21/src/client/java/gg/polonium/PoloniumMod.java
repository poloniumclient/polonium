package gg.polonium;

import gg.polonium.common.HostState;
import net.fabricmc.api.ModInitializer;

/**
 * Polonium Ghost: zero GUI w grze, zero wiadomości na czacie.
 * Wszystko sterowane z zewnętrznego WebView ClickGUI przez lokalny host.
 */
public class PoloniumMod implements ModInitializer {
    public static final String MODID = "polonium";

    @Override
    public void onInitialize() {
        HostState.start();
    }
}
