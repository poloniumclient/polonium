package gg.polonium;

import gg.polonium.common.HostState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * Ghost tick: zero HUD, zero czatu, wszystko cicho.
 * Odpalane z ogona MinecraftClient.tick przez Mixin.
 */
public final class Modules {
    private static final Random RND = new Random();
    private static long lastAura = 0;
    private static int auraJitter = 0;
    private static long lastClick = 0;
    private static boolean clickHeld = false;
    private static boolean gammaTouched = false;
    private static double gammaPrev = 1.0;
    private static boolean glowWasOn = false;
    private static boolean reachTouched = false;

    private Modules() {}

    /** Reach przez atrybut PLAYER_ENTITY_INTERACTION_RANGE (vanilla 3.0). Niewidoczne, bez mixinów. */
    private static void reachTick(ClientPlayerEntity p) {
        if (HostState.isOn("reach")) {
            EntityAttributeInstance inst = p.getAttributeInstance(EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE);
            if (inst != null) {
                reachTouched = true;
                inst.setBaseValue(HostState.getDouble("reach", "range", 3.4));
            }
        } else if (reachTouched) {
            EntityAttributeInstance inst = p.getAttributeInstance(EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE);
            if (inst != null) inst.setBaseValue(3.0);
            reachTouched = false;
        }
    }

    /** Zwraca skalę velocity {h, v} w procentach albo null gdy mod wył. Czytane przez VelocityMixin. */
    public static float[] velocityScale() {
        if (!HostState.isOn("velocity")) return null;
        float h = (float) HostState.getDouble("velocity", "horizontal", 90);
        float v = (float) HostState.getDouble("velocity", "vertical", 100);
        return new float[]{h, v};
    }

    public static void tick(MinecraftClient client) {
        try {
            ClientPlayerEntity p = client.player;
            if (p == null || client.world == null || client.interactionManager == null) return;

            // --- sprint (ghost: tylko w ruchu, nie na sneak) ---
            if (HostState.isOn("sprint") && !p.isSneaking()
                    && (p.input.pressingForward || p.input.pressingBack || p.input.pressingLeft || p.input.pressingRight)
                    && p.getHungerManager().getFoodLevel() > 6) {
                p.setSprinting(true);
            }

            // --- reach (atrybut) ---
            reachTick(p);

            // --- nofall ---
            if (HostState.isOn("nofall")) p.fallDistance = 0;

            // --- fullbright (gamma), z przywróceniem po wyłączeniu ---
            if (HostState.isOn("fullbright")) {
                if (!gammaTouched) {
                    gammaPrev = client.options.getGamma().getValue();
                    gammaTouched = true;
                }
                client.options.getGamma().setValue(16.0);
            } else if (gammaTouched) {
                client.options.getGamma().setValue(gammaPrev);
                gammaTouched = false;
            }

            // --- glow esp (outline zamiast boxów = niewidoczne na nagraniu jako cheat) ---
            boolean glowOn = HostState.isOn("esp");
            if (glowOn || glowWasOn) {
                List<PlayerEntity> players = client.world.getEntitiesByClass(
                        PlayerEntity.class, p.getBoundingBox().expand(64),
                        e -> e != p && e.isAlive());
                for (PlayerEntity e : players) e.setGlowing(glowOn);
                glowWasOn = glowOn;
            }

            // --- fly (hover, bez creative flaga) ---
            if (HostState.isOn("fly")) {
                double speed = HostState.getDouble("fly", "speed", 1.0);
                p.fallDistance = 0;
                Vec3d v = p.getVelocity();
                double up = 0;
                if (p.input.jumping) up = 0.55 * speed;
                else if (p.input.sneaking) up = -0.55 * speed;
                p.setVelocity(v.x, up, v.z);
            }

            // --- killaura (ghost: tylko gracze, jitter cps) ---
            if (HostState.isOn("killaura")) {
                double range = HostState.getDouble("killaura", "range", 3.2);
                int cps = Math.max(1, HostState.getInt("killaura", "cps", 11) + auraJitter);
                long now = System.currentTimeMillis();
                if (now - lastAura >= 1000L / cps) {
                    Entity target = nearest(client, p, range);
                    if (target != null) {
                        client.interactionManager.attackEntity(p, target);
                        p.swingHand(Hand.MAIN_HAND);
                        lastAura = now;
                        auraJitter = RND.nextInt(5) - 2; // -2..+2 cps humanizacji
                    }
                }
            }

            // --- aim assist (delikatny lerp, factor z hosta) ---
            if (HostState.isOn("aimassist")) {
                double dist = HostState.getDouble("aimassist", "distance", 4.5);
                double speed = HostState.getDouble("aimassist", "speed", 45) / 1000.0; // 0..~0.1
                Entity target = nearest(client, p, dist);
                if (target != null) aimAt(p, target, Math.min(0.12, Math.max(0.01, speed)));
            }

            // --- autoclicker (tylko gdy celujesz w byt, cicha pomoc) ---
            if (HostState.isOn("autoclicker") && client.crosshairTarget instanceof EntityHitResult) {
                int min = HostState.getInt("autoclicker", "minCps", 9);
                int max = HostState.getInt("autoclicker", "maxCps", 14);
                long now = System.currentTimeMillis();
                int interval = 1000 / Math.max(1, min + RND.nextInt(Math.max(1, max - min + 1)));
                if (!clickHeld && now - lastClick >= interval) {
                    client.options.attackKey.setPressed(true);
                    clickHeld = true;
                } else if (clickHeld && now - lastClick >= interval + 45) {
                    client.options.attackKey.setPressed(false);
                    clickHeld = false;
                    lastClick = now;
                }
            } else if (clickHeld) {
                client.options.attackKey.setPressed(false);
                clickHeld = false;
            }
        } catch (Throwable ignored) {
            // ghost nigdy nie crashuje gry
        }
    }

    private static Entity nearest(MinecraftClient client, ClientPlayerEntity p, double range) {
        Box box = p.getBoundingBox().expand(range);
        List<PlayerEntity> players = client.world.getEntitiesByClass(
                PlayerEntity.class, box, e -> e != p && e.isAlive());
        return players.stream()
                .min(Comparator.comparingDouble(e -> e.squaredDistanceTo(p)))
                .orElse(null);
    }

    private static void aimAt(ClientPlayerEntity p, Entity target, double factor) {
        Vec3d eyes = p.getEyePos();
        Vec3d t = target.getBoundingBox().getCenter();
        Vec3d d = t.subtract(eyes);
        double distXZ = Math.sqrt(d.x * d.x + d.z * d.z);
        float yaw = (float) (MathHelper.atan2(d.z, d.x) * 57.2957763671875) - 90.0f;
        float pitch = (float) (-(MathHelper.atan2(d.y, distXZ) * 57.2957763671875));
        p.setYaw(lerpAngle(p.getYaw(), yaw, factor));
        p.setPitch(MathHelper.lerp((float) factor, p.getPitch(), MathHelper.clamp(pitch, -90, 90)));
    }

    private static float lerpAngle(float a, float b, double f) {
        float d = MathHelper.wrapDegrees(b - a);
        return a + (float) (d * f);
    }

    /** Czyści ślady po wygaszeniu (np. glow). Wołane gdy host znika. */
    public static void resetVisuals(MinecraftClient client) {
        try {
            if (gammaTouched && client.options != null) {
                client.options.getGamma().setValue(gammaPrev);
                gammaTouched = false;
            }
        } catch (Throwable ignored) {}
    }

    static {
        // gdyby host padł, nie zostawiaj gamma
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {}));
    }
}
