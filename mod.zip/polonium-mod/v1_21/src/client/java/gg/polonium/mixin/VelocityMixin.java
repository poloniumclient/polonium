package gg.polonium.mixin;

import gg.polonium.Modules;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class VelocityMixin {
    @Inject(method = "setVelocityClient", at = @At("HEAD"), cancellable = true)
    private void polonium$velocity(Vec3d velocity, CallbackInfo ci) {
        float[] s = Modules.velocityScale();
        if (s != null) {
            ((Entity) (Object) this).setVelocity(
                    velocity.x * s[0] / 100.0,
                    velocity.y * s[1] / 100.0,
                    velocity.z * s[2] / 100.0);
            ci.cancel();
        }
    }
}
